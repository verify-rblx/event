import { GoogleGenAI } from "@google/genai";

export const generatePetLore = async (petName: string, rarity: string): Promise<string> => {
  if (!process.env.API_KEY) {
    console.warn("Gemini API Key not found. Returning mock lore.");
    return `The legendary ${petName} is a mysterious entity found in the depths of the Roblox multiverse. Its ${rarity} status makes it highly sought after by collectors. (Mock AI Response)`;
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `Write a short, funny, chaotic 'brainrot' style description (max 2 sentences) for a fictional Roblox pet named "${petName}" with rarity "${rarity}". Include made-up trading value in 'Robux'.`;
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    
    return response.text || "No lore found in the void.";
  } catch (error) {
    console.error("Error generating pet lore:", error);
    return "The ancient scrolls are unreadable at this moment (API Error).";
  }
};