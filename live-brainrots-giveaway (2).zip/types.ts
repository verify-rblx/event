export enum Rarity {
  COMMON = 'COMMON',
  RARE = 'RARE',
  EPIC = 'EPIC',
  LEGENDARY = 'LEGENDARY',
  RADIOACTIVE = 'RADIOACTIVE',
  SECRET = 'SECRET',
}

export interface Pet {
  id: string;
  name: string;
  rarity: Rarity;
  imageUrl: string;
  description?: string; // AI Generated lore
}

export interface ActivityItem {
  id: string;
  username: string;
  handle: string;
  action: string;
  target: string;
  avatarUrl: string;
  time: string;
}

export interface RobloxProfile {
  id: number;
  username: string;
  displayName: string;
  description: string;
  created: string;
  avatarUrl: string;
  profileUrl: string;
}

export interface UserState {
  username: string;
  isSaved: boolean;
  profile?: RobloxProfile;
}