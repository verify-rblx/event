import React, { useEffect, useState } from 'react';
import { Pet } from '../types';
import { X, Sparkles, Loader2 } from 'lucide-react';
import { generatePetLore } from '../services/geminiService';

interface PetModalProps {
  pet: Pet | null;
  onClose: () => void;
}

const PetModal: React.FC<PetModalProps> = ({ pet, onClose }) => {
  const [lore, setLore] = useState<string>("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (pet) {
      setLoading(true);
      setLore("");
      generatePetLore(pet.name, pet.rarity).then(text => {
        setLore(text);
        setLoading(false);
      });
    }
  }, [pet]);

  if (!pet) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-md transition-opacity" 
        onClick={onClose}
      ></div>

      {/* Content */}
      <div className="relative bg-[#0f172a]/80 backdrop-blur-xl border border-white/20 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden transform transition-all scale-100 text-white">
        <button 
            onClick={onClose}
            className="absolute top-3 right-3 p-2 hover:bg-white/10 rounded-full text-gray-400 hover:text-white transition-colors z-10"
        >
            <X size={20} />
        </button>

        <div className="p-6">
            <div className="flex flex-col items-center">
                <div className="w-32 h-32 bg-white/5 rounded-full mb-4 flex items-center justify-center p-2 border border-white/10 shadow-inner">
                    <img src={pet.imageUrl} alt={pet.name} className="w-full h-full object-contain animate-roll" />
                </div>
                
                <h2 className="text-2xl font-bold text-white mb-1 drop-shadow-md">{pet.name}</h2>
                <span className="bg-purple-500/20 border border-purple-500/30 text-purple-200 px-3 py-1 rounded-full text-xs font-bold uppercase mb-6 shadow-sm">
                    {pet.rarity}
                </span>

                <div className="w-full bg-indigo-500/10 rounded-xl p-5 border border-indigo-400/20 relative">
                    <div className="absolute top-4 left-4">
                        <Sparkles size={16} className="text-indigo-300" />
                    </div>
                    
                    <div className="pl-6">
                        <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider mb-2">AI Generated Lore</h4>
                        {loading ? (
                            <div className="flex items-center gap-2 text-indigo-200/70 text-sm">
                                <Loader2 size={16} className="animate-spin" />
                                <span>Consulting the Brainrot Oracle...</span>
                            </div>
                        ) : (
                            <p className="text-sm text-indigo-100 leading-relaxed italic">
                                "{lore}"
                            </p>
                        )}
                    </div>
                </div>

                <div className="mt-6 flex w-full gap-3">
                    <button onClick={onClose} className="flex-1 py-3 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-sm transition-colors border border-white/5">
                        Close
                    </button>
                    <button className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white font-bold rounded-xl text-sm shadow-lg shadow-red-900/40 transition-colors border border-red-400/50">
                        Add to Wishlist
                    </button>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default PetModal;