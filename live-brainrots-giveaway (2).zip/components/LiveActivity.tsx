import React, { useEffect, useState, useRef } from 'react';
import { ActivityItem } from '../types';
import { INITIAL_ACTIVITIES, MOCK_PETS, ROBLOX_COMMUNITY_MEMBERS } from '../constants';
import { fetchRobloxAvatar } from '../services/robloxService';

interface LiveActivityProps {
  className?: string;
}

const LiveActivity: React.FC<LiveActivityProps> = ({ className }) => {
  const [activities, setActivities] = useState<ActivityItem[]>(INITIAL_ACTIVITIES);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Simulate incoming live activity
  useEffect(() => {
    const generateActivity = async () => {
      const randomPet = MOCK_PETS[Math.floor(Math.random() * MOCK_PETS.length)];
      
      // Pick a random real community member
      const randomMember = ROBLOX_COMMUNITY_MEMBERS[Math.floor(Math.random() * ROBLOX_COMMUNITY_MEMBERS.length)];
      
      // Fetch Real Avatar
      let avatarUrl = `https://ui-avatars.com/api/?name=${randomMember.username}&background=random`;
      try {
        const realAvatar = await fetchRobloxAvatar(randomMember.id);
        if (realAvatar) {
          avatarUrl = realAvatar;
        }
      } catch (e) {
        console.error("Error fetching live activity avatar", e);
      }
      
      // Construct a real-looking activity item
      const newActivity: ActivityItem = {
        id: Date.now().toString(),
        username: randomMember.username,
        handle: `@${randomMember.username}`,
        action: Math.random() > 0.5 ? 'found' : 'claimed',
        target: randomPet.name,
        avatarUrl: avatarUrl,
        time: 'just now'
      };

      setActivities(prev => [newActivity, ...prev].slice(0, 20)); // Keep last 20
    };

    const interval = setInterval(() => {
      generateActivity();
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`bg-white/10 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 overflow-hidden flex flex-col h-[600px] sticky top-8 ${className}`}>
      <div className="p-5 border-b border-white/10 bg-white/5 z-10">
        <h3 className="font-bold text-white text-lg">Live Activity</h3>
        <p className="text-gray-300 text-xs">Recent claims (simulated)</p>
      </div>

      <div className="overflow-y-auto flex-1 p-4 space-y-4 custom-scrollbar" ref={scrollRef}>
        {activities.map((activity) => (
          <div key={activity.id} className="flex gap-3 items-start animate-fade-in group hover:bg-white/5 p-2 rounded-lg transition-colors">
            <img 
                src={activity.avatarUrl} 
                alt="avatar" 
                className="w-8 h-8 rounded-full border border-white/20 bg-black/20 animate-roll object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${activity.username}&background=random`;
                }}
            />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-baseline gap-1">
                <span className="text-sm font-bold text-gray-100 truncate max-w-[100px]">{activity.username}</span>
                <span className="text-xs text-gray-400 truncate max-w-[80px]">{activity.handle}</span>
              </div>
              <p className="text-sm text-gray-300 leading-snug">
                {activity.action} <span className="font-semibold text-red-300">{activity.target}</span>
              </p>
              <span className="text-[10px] text-gray-500 mt-1 block">{activity.time}</span>
            </div>
          </div>
        ))}
      </div>
      
      {/* Fade at bottom */}
      <div className="h-12 bg-gradient-to-t from-black/20 to-transparent pointer-events-none absolute bottom-0 w-full"></div>
    </div>
  );
};

export default LiveActivity;