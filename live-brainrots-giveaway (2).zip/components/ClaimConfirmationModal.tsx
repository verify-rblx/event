import React from 'react';
import { Pet } from '../types';
import { X } from 'lucide-react';

interface Props {
  pets: Pet[];
  username: string;
  onConfirm: () => void;
  onCancel: () => void;
}

const ClaimConfirmationModal: React.FC<Props> = ({ pets, username, onConfirm, onCancel }) => {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={onCancel}></div>
      <div className="relative bg-white text-gray-900 rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-fade-in">
        <div className="p-5 border-b border-gray-100 flex justify-between items-center">
          <h3 className="text-lg font-bold text-gray-900">Confirm Selection</h3>
          <button onClick={onCancel} className="text-gray-400 hover:text-gray-600 transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6 space-y-6">
           {/* Selected Items List */}
           <div className="space-y-3">
             {pets.map(pet => (
               <div key={pet.id} className="flex items-center gap-4 p-2 rounded-xl border border-gray-100 hover:bg-gray-50 transition-colors">
                 <div className="w-14 h-14 bg-gray-100 rounded-lg p-1 flex items-center justify-center">
                   <img src={pet.imageUrl} className="w-full h-full object-contain animate-roll" alt={pet.name} />
                 </div>
                 <div>
                   <p className="font-bold text-sm text-gray-800">{pet.name}</p>
                   <p className="text-xs text-gray-500 uppercase font-semibold tracking-wider">{pet.rarity}</p>
                 </div>
               </div>
             ))}
           </div>

           {/* Username Confirmation */}
           <div>
             <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1 block">Roblox Username</label>
             <div className="text-lg font-bold text-gray-800">@{username}</div>
           </div>
        </div>

        <div className="p-6 pt-2 flex gap-3">
          <button 
            onClick={onCancel} 
            className="flex-1 py-3 rounded-xl font-bold text-sm border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={onConfirm} 
            className="flex-1 py-3 rounded-xl font-bold text-sm bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-900/20 transition-colors"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};

export default ClaimConfirmationModal;