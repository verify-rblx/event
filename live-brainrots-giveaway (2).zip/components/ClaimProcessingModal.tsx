import React, { useEffect, useState } from 'react';
import { CheckCircle2, Loader2, X } from 'lucide-react';

interface Props {
  onComplete: () => void;
  onCancel: () => void;
}

const STEPS = [
  "Connecting to account...",
  "Encrypting item transfer...",
  "Finalizing confirmation..."
];

const ClaimProcessingModal: React.FC<Props> = ({ onComplete, onCancel }) => {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    if (currentStep < STEPS.length) {
      const timeout = setTimeout(() => {
        setCurrentStep(prev => prev + 1);
      }, 1500); // 1.5s per step
      return () => clearTimeout(timeout);
    }
    // Auto-completion removed to require user interaction on "Accept"
  }, [currentStep]);

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md"></div>
      <div className="relative bg-white text-gray-900 rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-fade-in p-8">
         {/* Header */}
         <button onClick={onCancel} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
            <X size={20} />
         </button>

         <div className="mb-6">
           <h3 className="text-2xl font-bold mb-2 text-gray-900">Processing your claim</h3>
           <p className="text-gray-500 text-sm">Please keep this tab open.</p>
         </div>

         {/* Steps */}
         <div className="space-y-5 mb-8">
           {STEPS.map((step, index) => {
             const isCompleted = currentStep > index;
             const isCurrent = currentStep === index;
             
             return (
               <div key={index} className="flex items-center gap-3 transition-all duration-300">
                 {isCompleted ? (
                   <CheckCircle2 className="text-green-500 flex-shrink-0" size={24} />
                 ) : isCurrent ? (
                   <Loader2 className="text-red-500 animate-spin flex-shrink-0" size={24} />
                 ) : (
                   <div className="w-6 h-6 rounded-full border-2 border-gray-200 flex-shrink-0"></div>
                 )}
                 <span className={`font-medium ${isCompleted || isCurrent ? 'text-gray-900' : 'text-gray-400'}`}>
                   {step}
                 </span>
               </div>
             );
           })}
         </div>

         {/* Actions */}
         <div className="flex gap-3">
            <button 
                onClick={onCancel} 
                className="flex-1 py-3 border border-gray-300 rounded-xl font-bold text-gray-600 hover:bg-gray-50 transition-colors"
            >
                Cancel
            </button>
            <button 
                onClick={onComplete} 
                disabled={currentStep < STEPS.length}
                className={`flex-1 py-3 rounded-xl font-bold text-white transition-all duration-300 ${
                    currentStep >= STEPS.length 
                    ? 'bg-red-600 hover:bg-red-700 shadow-lg shadow-red-600/30 animate-pulse cursor-pointer' 
                    : 'bg-gray-300 cursor-not-allowed'
                }`}
            >
                {currentStep >= STEPS.length ? 'Accept' : 'Processing...'}
            </button>
         </div>
      </div>
    </div>
  );
};

export default ClaimProcessingModal;