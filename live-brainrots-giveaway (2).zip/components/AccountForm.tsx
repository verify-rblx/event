import React, { useState } from 'react';
import { User, Loader2 } from 'lucide-react';
import { UserState } from '../types';
import { fetchRobloxProfile } from '../services/robloxService';

interface AccountFormProps {
  userState: UserState;
  setUserState: React.Dispatch<React.SetStateAction<UserState>>;
  selectedCount: number;
  onClaim: () => void;
}

const AccountForm: React.FC<AccountFormProps> = ({ userState, setUserState, selectedCount, onClaim }) => {
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    if (inputValue.trim().length === 0) return;
    
    setLoading(true);
    setError('');

    try {
      const profile = await fetchRobloxProfile(inputValue);
      setUserState({ username: profile.username, isSaved: true, profile });
    } catch (err) {
      setError('Could not find user. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChangeUser = () => {
    setUserState({ username: '', isSaved: false, profile: undefined });
    setInputValue('');
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 mb-8 overflow-hidden">
      <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
      
        {/* Left: Input Area or Profile Display */}
        <div className="lg:col-span-2">
          {!userState.isSaved ? (
            <div className="space-y-4">
               <div className="flex items-center gap-2 mb-2">
                <User className="text-white/80" size={20} />
                <h2 className="text-lg font-bold text-white">Roblox Account</h2>
              </div>
              
              <p className="text-xs text-gray-300 mb-4">
                Real Roblox info appears after saving your username.
              </p>

              <div className="flex gap-2">
                <div className="relative flex-grow">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">@</span>
                  <input
                    type="text"
                    placeholder="Enter Roblox username"
                    className="w-full pl-8 pr-4 py-3 bg-black/20 border border-white/10 text-white placeholder-gray-400 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all text-sm backdrop-blur-sm"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSave()}
                  />
                </div>
                <button
                  onClick={handleSave}
                  disabled={loading}
                  className="bg-red-500/80 hover:bg-red-500 text-white font-bold py-3 px-6 rounded-lg transition-all text-sm min-w-[100px] flex justify-center items-center backdrop-blur-sm border border-red-400/30"
                >
                  {loading ? <Loader2 size={18} className="animate-spin" /> : 'Save'}
                </button>
              </div>
              {error && <p className="text-red-300 text-xs mt-2 font-medium bg-red-900/20 px-2 py-1 rounded w-fit">{error}</p>}
            </div>
          ) : (
            // SAVED STATE - ROBLOX CARD PROFILE
            <div className="flex flex-col sm:flex-row gap-6 items-start h-full relative">
                {/* Close/Change Button Top Right */}
                 <button 
                    onClick={handleChangeUser}
                    className="absolute -top-2 -right-2 text-xs text-white/50 hover:text-white px-2 py-1 transition-colors"
                  >
                    Change
                  </button>

               {/* Avatar */}
               <div className="flex-shrink-0">
                  <img 
                    src={userState.profile?.avatarUrl} 
                    alt="avatar" 
                    className="w-20 h-20 rounded-full bg-white/5 object-cover border-4 border-white/10 shadow-lg animate-roll"
                  />
               </div>

               {/* Info */}
               <div className="flex-grow min-w-0">
                  {/* Header: Name and Handle */}
                  <div className="mb-4">
                    <h2 className="text-xl font-extrabold text-white leading-none drop-shadow-md">
                        {userState.profile?.displayName}
                    </h2>
                    <p className="text-sm text-gray-300 font-medium mt-1">@{userState.profile?.username}</p>
                  </div>

                  {/* Stats Row: ID, Joined, Open Button */}
                  <div className="flex flex-wrap items-center gap-6 mb-5 border-b border-white/10 pb-5">
                     <div>
                        <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-0.5">User ID</p>
                        <p className="text-sm font-bold text-gray-200">{userState.profile?.id}</p>
                     </div>
                     <div>
                        <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-0.5">Joined</p>
                        <p className="text-sm font-bold text-gray-200">{userState.profile?.created}</p>
                     </div>
                     <div className="flex items-end h-full">
                        <a 
                            href={userState.profile?.profileUrl} 
                            target="_blank" 
                            rel="noreferrer"
                            className="text-sm font-bold text-blue-300 hover:text-blue-200 flex items-center gap-1 leading-none mt-2 transition-colors"
                        >
                            Open <span className="text-xs">↗</span>
                        </a>
                     </div>
                  </div>

                  {/* Description */}
                  <div>
                    <h3 className="text-xs font-bold text-gray-300 mb-1">Description</h3>
                    <p className="text-xs text-gray-400 leading-relaxed line-clamp-3 whitespace-pre-line">
                        {userState.profile?.description}
                    </p>
                  </div>
               </div>
            </div>
          )}
        </div>

        {/* Right: Stats & CTA */}
        <div className="lg:col-span-1 border-l border-white/10 lg:pl-6 flex flex-col justify-center">
           <div className="mb-4">
              <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Selected Items</p>
              <p className="text-4xl font-extrabold text-white drop-shadow-sm">{selectedCount}</p>
           </div>
           <button
              onClick={onClaim}
              disabled={selectedCount === 0}
              className={`w-full py-4 rounded-xl font-bold text-white shadow-lg transform transition-all active:scale-95 flex items-center justify-center gap-2 border ${
                  selectedCount > 0 
                  ? 'bg-red-500/80 hover:bg-red-500 border-red-400/50 shadow-red-900/20' 
                  : 'bg-white/5 border-white/5 text-gray-400 cursor-not-allowed'
              }`}
           >
              Claim Selected ({selectedCount})
           </button>
        </div>

      </div>
    </div>
  );
};

export default AccountForm;