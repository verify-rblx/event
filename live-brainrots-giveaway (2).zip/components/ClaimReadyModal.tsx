import React, { useEffect, useState } from 'react';
import { CheckCircle, ExternalLink, X } from 'lucide-react';

interface Props {
  onJoin: () => void;
  onCancel: () => void;
}

const ClaimReadyModal: React.FC<Props> = ({ onJoin, onCancel }) => {
  const [timeLeft, setTimeLeft] = useState(3);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(prev => prev - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      onJoin();
    }
  }, [timeLeft, onJoin]);

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onCancel}></div>
      <div className="relative bg-white text-gray-900 rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-fade-in p-6">
        <button onClick={onCancel} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
          <X size={20} />
        </button>

        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4 text-green-500">
            <CheckCircle size={32} strokeWidth={3} />
          </div>
          <h3 className="text-2xl font-bold text-gray-900">Ready to Claim</h3>
        </div>

        <div className="bg-gray-50 border border-dashed border-gray-300 rounded-xl p-4 mb-6 text-left">
          <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Instructions</p>
          <p className="text-sm text-gray-700 leading-relaxed">
            Join the private server and find <strong>Host</strong> in the spawn area to complete your claim.
          </p>
        </div>

        <div className="text-center mb-6">
          <p className="text-sm text-gray-500 animate-pulse">
            Redirecting in <span className="font-bold text-gray-800">{timeLeft}</span> seconds...
          </p>
        </div>

        <div className="flex gap-3">
           <button
             onClick={onCancel}
             className="px-6 py-3 border border-gray-200 rounded-xl font-bold text-gray-600 hover:bg-gray-50 transition-colors"
           >
             Cancel
           </button>
           <button
             onClick={onJoin}
             className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-lg shadow-red-900/20 flex items-center justify-center gap-2 transition-transform active:scale-95"
           >
             <ExternalLink size={18} />
             Join Now
           </button>
        </div>
      </div>
    </div>
  );
};

export default ClaimReadyModal;