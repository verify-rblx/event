import React from 'react';
import { Pet } from '../types';
import { RARITY_COLORS } from '../constants';
import { Sparkles, Info } from 'lucide-react';

interface PetCardProps {
  pet: Pet;
  isSelected: boolean;
  onSelect: (id: string) => void;
  onInfo: (pet: Pet) => void;
}

const PetCard: React.FC<PetCardProps> = ({ pet, isSelected, onSelect, onInfo }) => {
  return (
    <div 
        className={`group relative bg-white/10 backdrop-blur-md rounded-2xl p-4 shadow-lg border transition-all duration-300 hover:shadow-xl hover:bg-white/15 ${
            isSelected ? 'border-purple-500 ring-2 ring-purple-500 ring-opacity-50' : 'border-white/10 hover:border-white/30'
        }`}
    >
      
      {/* Rarity Badge */}
      <div className="flex justify-center mb-4">
        <span className={`${RARITY_COLORS[pet.rarity]} text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-widest shadow-lg border border-white/20`}>
          {pet.rarity}
        </span>
      </div>

      {/* Image */}
      <div className="relative aspect-square w-full mb-4 overflow-hidden rounded-xl bg-black/20 border border-white/5 flex items-center justify-center shadow-inner">
         <div className="w-3/4 h-3/4 transition-transform duration-300 group-hover:scale-110">
           <img 
              src={pet.imageUrl} 
              alt={pet.name} 
              className="w-full h-full object-contain drop-shadow-xl animate-roll"
              loading="lazy"
           />
         </div>
      </div>

      {/* Details */}
      <div className="text-center mb-4">
        <h3 className="font-bold text-white text-sm truncate px-2 drop-shadow-sm">{pet.name}</h3>
      </div>

      {/* Action Button */}
      <button
        onClick={() => onSelect(pet.id)}
        className={`w-full py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all duration-200 border ${
            isSelected 
            ? 'bg-purple-600/90 text-white shadow-lg shadow-purple-900/30 border-purple-400/50' 
            : 'bg-white/10 text-white hover:bg-purple-500 hover:border-purple-400 border-white/10'
        }`}
      >
        {isSelected ? 'Selected' : 'Select'}
      </button>
    </div>
  );
};

export default PetCard;