import React from 'react';
import { Radio, Youtube } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="mb-8">
      <div className="flex items-center justify-between">
        <div className="drop-shadow-lg">
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Live Brainrots Giveaway
          </h1>
          <p className="text-gray-200 mt-1 text-sm md:text-base font-medium">
            Claim limited-time pets before they expire.
          </p>
          
          <div className="mt-2 flex flex-col sm:flex-row sm:items-center gap-4">
            <p className="text-white/60 text-xs font-medium">
              Made by Cærl Nasād.
            </p>
            
            <div className="flex items-center gap-2">
              <a 
                href="https://www.tiktok.com/@carlzisnothere" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-white/60 hover:text-[#ff0050] transition-colors text-xs font-bold bg-white/5 px-2 py-1 rounded-md border border-white/5 hover:bg-white/10"
              >
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                </svg>
                TikTok
              </a>
              <a 
                href="https://www.youtube.com/@StrangerToGargatuanTV" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-white/60 hover:text-[#FF0000] transition-colors text-xs font-bold bg-white/5 px-2 py-1 rounded-md border border-white/5 hover:bg-white/10"
              >
                <Youtube size={14} />
                YouTube
              </a>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2 bg-red-600/90 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse shadow-lg border border-red-500/50">
          <Radio size={14} className="animate-ping absolute inline-flex h-3 w-3 rounded-full bg-red-400 opacity-75" />
          <Radio size={14} />
          <span>LIVE</span>
        </div>
      </div>
    </header>
  );
};

export default Header;