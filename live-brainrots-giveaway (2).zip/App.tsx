import React, { useState } from 'react';
import Header from './components/Header';
import AccountForm from './components/AccountForm';
import PetCard from './components/PetCard';
import LiveActivity from './components/LiveActivity';
import PetModal from './components/PetModal';
import ClaimConfirmationModal from './components/ClaimConfirmationModal';
import ClaimProcessingModal from './components/ClaimProcessingModal';
import ClaimReadyModal from './components/ClaimReadyModal';
import { MOCK_PETS, REDIRECT_URL } from './constants';
import { UserState, Pet } from './types';
import { AlertTriangle, X } from 'lucide-react';

const App: React.FC = () => {
  const [userState, setUserState] = useState<UserState>({ username: '', isSaved: false });
  const [selectedPets, setSelectedPets] = useState<Set<string>>(new Set());
  const [viewingPet, setViewingPet] = useState<Pet | null>(null);
  const [showLimitWarning, setShowLimitWarning] = useState(false);
  
  // Claim Flow State
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showProcessingModal, setShowProcessingModal] = useState(false);
  const [showReadyModal, setShowReadyModal] = useState(false);

  const toggleSelect = (id: string) => {
    const newSelected = new Set(selectedPets);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      if (newSelected.size >= 3) {
        setShowLimitWarning(true);
        return;
      }
      newSelected.add(id);
    }
    setSelectedPets(newSelected);
  };

  const handleClaimClick = () => {
    if (!userState.isSaved) {
      alert("Please save your Roblox username first!");
      return;
    }
    setShowConfirmModal(true);
  };

  const handleConfirmClaim = () => {
    setShowConfirmModal(false);
    setShowProcessingModal(true);
  };

  const handleProcessingComplete = () => {
    setShowProcessingModal(false);
    setShowReadyModal(true);
  };

  const handleFinalRedirect = () => {
    window.location.href = REDIRECT_URL;
  };

  const getSelectedPetObjects = () => {
    return MOCK_PETS.filter(pet => selectedPets.has(pet.id));
  };

  return (
    <div 
      className="min-h-screen text-white bg-fixed bg-cover bg-center transition-all duration-500"
      style={{ 
        backgroundImage: `url('https://media1.tenor.com/m/1C0gJvJ4t8AAAAAd/pretty-sky-space.gif')`,
        backgroundColor: '#0f172a' // Fallback
      }}
    >
      {/* Overlay for readability if needed, but glass cards handle it */}
      <div className="min-h-screen bg-black/20 backdrop-blur-[1px]">
        <div className="max-w-[1400px] mx-auto p-4 md:p-8">
          
          <Header />

          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
            
            {/* Main Content: Left Side */}
            <div className="xl:col-span-9">
              
              <AccountForm 
                  userState={userState} 
                  setUserState={setUserState} 
                  selectedCount={selectedPets.size}
                  onClaim={handleClaimClick}
              />

              <div className="mb-4 flex items-center justify-between">
                  <h2 className="text-xl font-bold text-white shadow-black drop-shadow-md">Choose Pets</h2>
                  <span className="text-sm text-gray-300 font-medium">{selectedPets.size} selected (Max 3)</span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {MOCK_PETS.map((pet) => (
                  <PetCard
                    key={pet.id}
                    pet={pet}
                    isSelected={selectedPets.has(pet.id)}
                    onSelect={toggleSelect}
                    onInfo={setViewingPet}
                  />
                ))}
              </div>
              
              {/* Disclaimer */}
              <div className="mt-12 text-center text-white/40 text-xs py-8 border-t border-white/10">
                  <p>&copy; 2024 Live Brainrots Giveaway. Not affiliated with Roblox Corporation.</p>
              </div>
            </div>

            {/* Sidebar: Right Side */}
            <div className="xl:col-span-3 hidden xl:block">
              <LiveActivity />
            </div>

            {/* Mobile Live Activity (Below content on small screens) */}
            <div className="col-span-1 xl:hidden">
               <LiveActivity className="h-[400px] sticky top-0" />
            </div>

          </div>
        </div>
      </div>

      {/* Modals */}
      <PetModal pet={viewingPet} onClose={() => setViewingPet(null)} />

      {/* Claim Flow Modals */}
      {showConfirmModal && (
        <ClaimConfirmationModal 
            pets={getSelectedPetObjects()} 
            username={userState.username}
            onConfirm={handleConfirmClaim}
            onCancel={() => setShowConfirmModal(false)}
        />
      )}

      {showProcessingModal && (
        <ClaimProcessingModal 
            onComplete={handleProcessingComplete}
            onCancel={() => setShowProcessingModal(false)}
        />
      )}

      {showReadyModal && (
        <ClaimReadyModal
            onJoin={handleFinalRedirect}
            onCancel={() => setShowReadyModal(false)}
        />
      )}

      {/* Limit Warning Popup */}
      {showLimitWarning && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-md" onClick={() => setShowLimitWarning(false)}></div>
          <div className="bg-[#1a1a2e]/90 border border-white/10 text-white rounded-2xl shadow-2xl p-6 max-w-sm w-full relative transform scale-100 animate-fade-in backdrop-blur-xl">
            <button 
                onClick={() => setShowLimitWarning(false)} 
                className="absolute top-4 right-4 text-gray-400 hover:text-white p-1 bg-white/5 rounded-full hover:bg-white/10 transition-colors"
            >
                <X size={16} />
            </button>
            <div className="flex flex-col items-center text-center mt-2">
                <div className="w-14 h-14 bg-red-500/10 rounded-full flex items-center justify-center mb-4 text-red-400 shadow-sm border border-red-500/20">
                    <AlertTriangle size={28} />
                </div>
                <h3 className="text-xl font-extrabold text-white mb-2">Limit Reached!</h3>
                <p className="text-sm text-gray-300 mb-6 leading-relaxed">
                    You can only select up to <strong>3 Brainrots</strong> at a time. Please unselect one to choose another.
                </p>
                <button 
                    onClick={() => setShowLimitWarning(false)}
                    className="bg-white text-gray-900 hover:bg-gray-200 font-bold py-3.5 px-8 rounded-xl w-full transition-all active:scale-95 shadow-lg"
                >
                    Understood
                </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;