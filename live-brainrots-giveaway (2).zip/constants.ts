import { Pet, Rarity, ActivityItem } from './types';

export const REDIRECT_URL = "https://roblox.com.py/games/109983668079237/Steal-a-Brainrot?privateServerLinkCode=67071888670726806607964649986279";

export const MOCK_PETS: Pet[] = [
  {
    id: '1',
    name: 'Meowl',
    rarity: Rarity.RADIOACTIVE,
    imageUrl: 'https://brainroot.netlify.app/images/Meowl.png',
  },
  {
    id: '2',
    name: 'StrawberryElephant',
    rarity: Rarity.RADIOACTIVE,
    imageUrl: 'https://brainroot.netlify.app/images/StrawberryElephant.png',
  },
  {
    id: '3',
    name: 'Lavadorito Spinito',
    rarity: Rarity.SECRET,
    imageUrl: 'https://brainroot.netlify.app/images/Gemini.png',
  },
  {
    id: '4',
    name: 'W or L',
    rarity: Rarity.SECRET,
    imageUrl: 'https://brainroot.netlify.app/images/WorL.png',
  },
  {
    id: '5',
    name: '67',
    rarity: Rarity.SECRET,
    imageUrl: 'https://brainroot.netlify.app/images/67.png',
  },
  {
    id: '6',
    name: 'La Supreme Combinasion',
    rarity: Rarity.SECRET,
    imageUrl: 'https://static.beebom.com/wp-content/uploads/2025/07/La-Supreme-Combinasion.jpg',
  },
  {
    id: '7',
    name: 'Ketupat Kepat',
    rarity: Rarity.SECRET,
    imageUrl: 'https://static.beebom.com/wp-content/uploads/2025/07/Ketupat-Kepat.jpg',
  },
  {
    id: '8',
    name: 'Ketchuru and Musturu',
    rarity: Rarity.SECRET,
    imageUrl: 'https://static.beebom.com/wp-content/uploads/2025/07/Ketchuru-and-Musturu-1.jpg',
  }
];

// Real User IDs for simulation (Mix of random high IDs and some known ones to ensure variety)
// These represent "members" of the community
export const ROBLOX_COMMUNITY_MEMBERS = [
  { id: 1, username: 'Roblox' },
  { id: 156, username: 'Builderman' },
  { id: 261, username: 'Shedletsky' },
  { id: 16160, username: 'Stickmasterluke' },
  { id: 236079019, username: 'KreekCraft' },
  { id: 158332152, username: 'Flamingo' },
  { id: 52569, username: 'Telamon' },
  { id: 8752624, username: 'Guest_99' },
  { id: 189764, username: 'Clockwork' },
  { id: 20456308, username: 'DenisDaily' },
  { id: 489234, username: 'NoobMaster' },
  { id: 998877, username: 'BloxLover' },
  { id: 1234567, username: 'LuckyWinner' },
  { id: 7654321, username: 'PetHunter' },
  { id: 5000001, username: 'SpyderFan' },
  { id: 800000, username: 'Glitch' },
  { id: 900000, username: 'BaconHair' },
  { id: 35815907, username: 'GroupOwner' }
];

export const INITIAL_ACTIVITIES: ActivityItem[] = [
  {
    id: 'a1',
    username: 'Roblox',
    handle: '@Roblox',
    action: 'found',
    target: 'Meowl',
    avatarUrl: 'https://tr.rbxcdn.com/53eb9b17fe1432a801e7d8d2b77a08b3/150/150/AvatarHeadshot/Png',
    time: 'just now'
  }
];

export const RARITY_COLORS: Record<Rarity, string> = {
  [Rarity.COMMON]: 'bg-gray-400 text-white',
  [Rarity.RARE]: 'bg-blue-400 text-white',
  [Rarity.EPIC]: 'bg-purple-500 text-white',
  [Rarity.LEGENDARY]: 'bg-orange-400 text-white',
  [Rarity.RADIOACTIVE]: 'bg-lime-400 text-lime-900',
  [Rarity.SECRET]: 'bg-fuchsia-500 text-white',
};